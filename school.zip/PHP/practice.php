<?php
echo "<hr/>";
echo("HEY this is first php yeyeye code");
echo "<br/>";
$a=20;
$b=300;
$c=$a+$b;
echo "<hr/>";

echo "the result is :". $c;
echo "<hr/>";

echo "<br/>";
echo $a;
echo "<hr/>";

echo "<br/>";
echo$b;
echo "<hr/>";
if ($a>$b)
{
    echo "a is greater than b";
}
else if($a==$b)
{
    echo "a is equal to b";
}
else{
    echo "a is smaller";
}
echo "<br/>";
$index_array = ['a','b','c','d','e','1230'];
echo $index_array[2];
echo "<br/>";
echo $index_array[0];
echo "<br/>";
echo $index_array[1];
echo "<br/>";
echo $index_array[5];
echo "<br/>";
$associative_array = ["Dj"=>10,"Cj"=>15,"Aj"=>20];
echo $associative_array["Dj"]. " value of dj";
echo "<br/>";
echo $associative_array["Cj"]. " value of Cj";
echo "<br/>";
echo $associative_array["Aj"]. " value of Aj";
echo "<br/>";
for($i=0;$i<20;$i++)
{
    echo $i;
    echo "<br/>";
}
echo "<br/>";
while($a<30)
{
    echo $a;
    $a++;
    echo "<br/>";
}
echo "<br/>";
foreach($index_array as $ar)
{
    echo $ar;
    echo "<br/>";
}
echo "<br/>";
function anamul()
{
    echo "hello this is from inside the function";
}
anamul();
echo "<br/>";
if(isset($_GET['username']))
{
    echo "HELLO ". $_GET['username']. " this is successfully retrived";
}




?>