<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="practice.php" method="GET">
<input type="text" name="username">
<button type="submit">Click meee</button>
</form>



<body>
</html>