<?php
include("main.php");
pageHeader('Home Page');
?>
<h1>Welcome</h1>
<p>Welcome to Sarail Annada Govt. High School's website. You will get everthing you need if you are a teacher or a student. Select an option below to get our online facilities.</p>
<h1>Photo Gallery</h1>
<table>
<tr>
<td class="td3"><a href="photos/1.jpg"><img src="photos/1.jpg"/></a></td>
<td class="td3"><a href="photos/2.jpg"><img src="photos/2.jpg"/></a></td>
</tr>
<tr>
<td class="td3"><a href="photos/3.jpg"><img src="photos/3.jpg"/></a></td>
<td class="td3"><a href="photos/4.jpg"><img src="photos/4.jpg"/></a></td>
</tr>
<tr>
<td class="td3"><a href="photos/5.jpg"><img src="photos/1.jpg"/></a></td>
<td class="td3"><a href="photos/6.jpg"><img src="photos/2.jpg"/></a></td>
</tr>
<tr>
<td class="td3"><a href="photos/7.jpg"><img src="photos/3.jpg"/></a></td>
<td class="td3"><a href="photos/8.jpg"><img src="photos/4.jpg"/></a></td>
</tr>
</table>
<?php
pageFooter($conn);
?>